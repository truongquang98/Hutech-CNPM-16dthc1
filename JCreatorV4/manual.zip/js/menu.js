function startList() {

      if (document.all&&document.getElementById) {
            navRoot = document.getElementById("nav");
            for (i=0; i<navRoot.childNodes.length; i++) {
                  node = navRoot.childNodes[i];
                  if (node.nodeName=="LI") {
                        node.onmouseover=function() {
                              this.className+=" over";
                        }
                        node.onmouseout=function() {
                              this.className=this.className.replace >
                              (" over", "");
                        }
                  }
            }
      }

}


function svover(x) {

            nR = eval("document.getElementById('" + x + "')");

                 if (nR.className=="svout") {
                    nR.className="svover";
                    nR = ""
                  }

                  else {
                    nR.className="svout";
                    nR = ""
                  }


} 




